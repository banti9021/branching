# sign language > 2024-08-09 4:11am
https://universe.roboflow.com/vivek-8c5ks/sign-language-0vq18

Provided by a Roboflow user
License: CC BY 4.0

